import torch.nn as nn
import torch
import torch.nn.functional as F
from torch.nn import init


class ResBlock(nn.Module):
    def __init__(self, dim):
        super(ResBlock, self).__init__()

        self.conv1 = nn.Conv2d(dim, dim, kernel_size=3, padding=1, bias=True)
        self.relu = nn.ReLU()
        self.conv2 = nn.Conv2d(dim, dim, kernel_size=3, padding=1, bias=True)

    def forward(self, x):
        return x + self.conv2(self.relu(self.conv1(x)))

class ResBlock_2(nn.Module):
    def __init__(self, dim):
        super(ResBlock_2, self).__init__()

        self.conv_3_2 = nn.Conv2d(in_channels=2*dim, out_channels=2*dim, kernel_size=3, stride=1, padding=1, bias=True)
        self.conv_5_2 = nn.Conv2d(in_channels=2*dim, out_channels=2*dim, kernel_size=5, stride=1, padding=2, bias=True)
        self.conv_3 = nn.Conv2d(in_channels=dim, out_channels=dim, kernel_size=3, stride=1, padding=1, bias=True)
        self.conv_5 = nn.Conv2d(in_channels=dim, out_channels=dim, kernel_size=5, stride=1, padding=2, bias=True)
        self.relu = nn.ReLU(inplace=True)
        self.confusion1 = nn.Conv2d(in_channels=12*dim, out_channels=6*dim, kernel_size=1, stride=1, padding=0, bias=False)
        self.confusion2 = nn.Conv2d(in_channels=4*dim, out_channels=dim, kernel_size=1, stride=1, padding=0, bias=False)

    def forward(self, x):#1x16x96x96
        identity_data = x
        output_3 = self.relu(self.conv_3(x))
        output_5 = self.relu(self.conv_5(x))
        input_2 = torch.cat([output_3, output_5], 1)
        output_3_2 = self.relu(self.conv_3_2(input_2))#1x32x96x96
        output_5_2 = self.relu(self.conv_5_2(input_2))#1x32x96x96
        output = torch.cat([output_3_2, output_5_2], 1)

        output = self.confusion2(output)
        output = torch.add(output, identity_data)
        return output

class DMBlock1(nn.Module):
    def __init__(self, dim):
        super(DMBlock1, self).__init__()

        self.res1 = ResBlock_2(dim)

    def forward(self, x):
        x = self.res1(x)
        return x


class DMBlock2(nn.Module):
    def __init__(self, dim):
        super(DMBlock2, self).__init__()
        self.dowm_1 = nn.Conv2d(16, 8, kernel_size=3, padding=1, stride=1, bias=True)
        self.dowm_2 = nn.Conv2d(8, 16, kernel_size=3, padding=1, stride=1, bias=True)
        self.dowm_3 = nn.Conv2d(16, 16, kernel_size=3, padding=1, stride=2, bias=True)
        self.res1 = ResBlock(8)

    def forward(self, x):
        x = F.interpolate(x, scale_factor=2, mode='bilinear')
        x = self.res1(self.dowm_1(x))
        
        x = self.dowm_2(x)
        x = self.dowm_3(x)
        return x

 
class DMMBlock(nn.Module):
    def __init__(self, dim):
        super(DMMBlock, self).__init__()

        self.um1 = DMBlock1(dim)
        self.um2 = DMBlock2(dim)
        self.conv1 = nn.Conv2d(dim * 2, dim, kernel_size=1, padding=0, stride=1, bias=True)
        
           

    def forward(self, x):
        x1 = self.um1(x)
        x2 = self.um2(x)
        x = torch.cat((x1, x2), dim=1)#x={Tensor:(2,48,96,96)}
        x = self.conv1(x)
        

        return x


class UMBlock(nn.Module):
    def __init__(self, dim):
        super(UMBlock, self).__init__()

        self.conv1 = nn.Conv2d(dim, 1, kernel_size=3, padding=1, bias=True)
        self.conv2 = nn.Conv2d(1, dim, kernel_size=3, padding=1, bias=True)
        self.res1 = ResBlock(dim)

    def forward(self, x, y, Phi, PhiT):
        x_pixel = self.conv1(x)
        Phix = F.conv2d(x_pixel, Phi, padding=0, stride=32, bias=None)
        delta = y - Phix
        x_pixel_delta = nn.PixelShuffle(32)(F.conv2d(delta, PhiT, padding=0, bias=None))
        x = self.res1(x-self.conv2(x_pixel+x_pixel_delta)) + x

        return x


class DSFONet(nn.Module):
    def __init__(self, sensing_rate, LayerNo):
        super(DSFONet, self).__init__()

        self.measurement = int(sensing_rate * 1024)
        self.base = 16

        self.conv_1 = nn.Conv2d(1, int(1024*sensing_rate), kernel_size=3, padding=1,bias=True)
        self.conv_2 = nn.Conv2d(int(1024*sensing_rate), int(1024*sensing_rate), kernel_size=3, padding=1,bias=True)
        self.conv_3 = nn.Conv2d(int(1024*sensing_rate), 1, kernel_size=3, padding=1,bias=True)
        self.Phi = nn.Parameter(init.xavier_normal_(torch.Tensor(self.measurement, 1024)))
        self.conv1 = nn.Conv2d(1, self.base, kernel_size=3, padding=1, bias=True)
        self.conv2 = nn.Conv2d(self.base, 1, kernel_size=1, padding=0, bias=True)
        layer1 = []
        layer2 = []
        self.LayerNo = LayerNo
        for i in range(LayerNo):
            layer1.append(DMMBlock(self.base))
            layer2.append(UMBlock(self.base))
        self.fcs1 = nn.ModuleList(layer1)
        self.fcs2 = nn.ModuleList(layer2)

    def forward(self, x):
        Phi = self.Phi.contiguous().view(self.measurement, 1, 32, 32)
        PhiT = self.Phi.t().contiguous().view(1024, self.measurement, 1, 1)
        x_1=self.conv_1(x)
        x_2=self.conv_2(x_1+x)
        x_3=self.conv_3(x_2+x_1+x)
        y = F.conv2d(x_3, Phi, padding=0, stride=32, bias=None)
        x = F.conv2d(y, PhiT, padding=0, bias=None)
        x = nn.PixelShuffle(32)(x)

        x = self.conv1(x)
       
        x_1 = self.fcs2[0](x, y, Phi, PhiT)
        x__1 = self.fcs1[0](x_1)
        x_2 = self.fcs2[1](x__1, y, Phi, PhiT)
        x__2 = self.fcs1[1](x_2+x_1)
        x_3 = self.fcs2[2](x__2, y, Phi, PhiT)
        x__3 = self.fcs1[2](x_3+x_2)
        x_4 = self.fcs2[3](+x__3, y, Phi, PhiT)
        x__4 = self.fcs1[3](x_4+x_3)
        x_5 = self.fcs2[4](x__4, y, Phi, PhiT)
        x__5 = self.fcs1[4](x_5+x_4)
        x_6 = self.fcs2[5](x__5, y, Phi, PhiT)
        x__6 = self.fcs1[5](x_6+x_5)
        x_7 = self.fcs2[6](x__6, y, Phi, PhiT)
        x__7 = self.fcs1[6](x_7+x_6)
        x_8 = self.fcs2[7](x__7, y, Phi, PhiT)
        x__8 = self.fcs1[7](x_8+x_7)
        x_9 = self.fcs2[8](x__8, y, Phi, PhiT)
        x__9 = self.fcs1[8](x_9+x_8)
        x_10= self.fcs2[9](x__9, y, Phi, PhiT)
        x__10 = self.fcs1[9](x_10+x_9)
        x_11= self.fcs2[10](x__10, y, Phi, PhiT)
        x__11 = self.fcs1[10](x_11+x_10)
        x_12= self.fcs2[11](x__11, y, Phi, PhiT)
        x__12 = self.fcs1[11](x_12+x_11)
        x_13= self.fcs2[12](x__12, y, Phi, PhiT)
        x__13 = self.fcs1[12](x_13+x_12)
        x_14= self.fcs2[13](x__13, y, Phi, PhiT)
        x__14 = self.fcs1[13](x_14+x_13)
        x_15= self.fcs2[14](x__14, y, Phi, PhiT)
        x__15 = self.fcs1[14](x_15+x_14)
        x_16= self.fcs2[15](x__15, y, Phi, PhiT)
        x__16 = self.fcs1[15](x_16+x_15)

        x = self.conv2(x__16)


        phi_cons = torch.mm(self.Phi, self.Phi.t())
      

        
        return x, phi_cons
