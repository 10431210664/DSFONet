import torch
pthfile=r'./save_temp/DSFONet_group_1_ratio_0.01/net_params_100.pth'
model=torch.load(pthfile,map_location=torch.device('cuda'))
print(len(model))